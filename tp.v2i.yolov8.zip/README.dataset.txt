# tp > 2025-02-13 12:16am
https://universe.roboflow.com/yolo-v8-image-labeling/tp-rtcrm

Provided by a Roboflow user
License: CC BY 4.0

