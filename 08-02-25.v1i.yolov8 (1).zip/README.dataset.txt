# 08-02-25 > 2025-02-27 11:09pm
https://universe.roboflow.com/yolo-v8-image-labeling/08-02-25

Provided by a Roboflow user
License: CC BY 4.0

